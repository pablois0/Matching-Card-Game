//
//  ViewController.swift
//  MatchGameHome
//
//  Created by Pablo Moya  on 10/6/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var CardsButton: [UIButton]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showCardsOnButton()
    }

    func showCardsOnButton(){
        for tag in 0..<game.cards.count {
            if game.cards[tag].cellState == .Hidden{
                CardsButton[tag].setImage(UIImage(named: "Goomy") , for: .normal)
            } else {
                let name = game.cards[tag].name
                CardsButton[tag].setImage(UIImage(named: name) , for: .normal)

            }
        }
    }
    
    @IBAction func pressed(_ sender: UIButton) {
        game.proccedSelection(at: sender.tag)
        showCardsOnButton()
    }
    
}

